
package com.dishii.soh;
import org.libsdl.app.SDLActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;

import android.provider.Settings;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.util.concurrent.CountDownLatch;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import android.widget.SeekBar;

import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.os.Build;
import android.view.WindowManager;
import android.widget.Toast;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import android.util.Log;

import android.view.KeyEvent;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.graphics.Rect;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Looper;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import java.util.Arrays;

import java.util.concurrent.Executors;
import android.app.AlertDialog;

import android.view.InputDevice;
import android.os.Vibrator;
import android.os.VibrationEffect;

//This class is the main SDLActivity and just sets up a bunch of default files
public class MainActivity extends SDLActivity{

    SharedPreferences preferences;
    private static final CountDownLatch setupLatch = new CountDownLatch(1);
    private volatile boolean mIsAiming = false;
    private static final int COPY_BUFFER_SIZE = 65536;
    private static final int RUMBLE_MAX_DURATION_MS = 5000;
    private static final String DATA_FOLDER_NAME = BuildConfig.DEBUG ? "SOH93-Test" : "SOH";
    private static String currentDataRootPath = "/storage/emulated/0/" + DATA_FOLDER_NAME;
    private static final String PREF_DATA_ROOT_PATH = "dataRootPath";
    private static final String PREF_LEGACY_DATA_MIGRATION_COMPLETE = "legacyDataMigrationComplete";
    private static final String PREF_TOUCH_CONTROLS_DISABLED = "touchControlsDisabled";
    // Legacy key name: true means the touch controls are hidden, not visible.
    private static final String PREF_TOUCH_CONTROLS_HIDDEN = "controlsVisible";
    private static final String PREF_TOUCH_FACE_BUTTON_LAYOUT = "touchFaceButtonLayout";
    private static final String PREF_TOUCH_LEFT_STICK_FLOATING = "touchLeftStickFloating";
    private static final int TOUCH_FACE_BUTTON_LAYOUT_ABXY = 0;
    private static final int TOUCH_FACE_BUTTON_LAYOUT_BAYX = 1;
    private static final int TOUCH_FACE_BUTTON_LAYOUT_GAMECUBE = 2;
    private static final String SUPPORT_FILES_VERSION_MARKER = ".android_support_files_version";
    // Bump only for support archive/layout changes. Extractor YAML is content-versioned separately.
    private static final String SUPPORT_FILES_VERSION = "soh-9.3.1-torch-support-2-thai2";
    private AlertDialog dataRootMigrationDialog;
    private AlertDialog setupProgressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Log.i("SoH", "onCreate start");

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        // Apply Android's immersive window style while support files are prepared,
        // before the native renderer creates its fullscreen window.
        setWindowStyle(true);

        preferences = getSharedPreferences("com.dishii.soh.prefs", Context.MODE_PRIVATE);
        updateCurrentDataRootPath();

        Log.i("SoH", "hasStoragePermission=" + hasStoragePermission());

        // Check if storage permissions are granted
        if (hasStoragePermission()) {
            beginSetupOrChooseDataRoot();
        } else {
            requestStoragePermission();
        }

        setupControllerOverlay();
        attachController();

        Log.i("SoH", "onCreate complete");
    }

    public static void waitForSetupFromNative() {
        try {
            setupLatch.await();  // Block until setup is complete
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static String getDataRootPathFromNative() {
        return currentDataRootPath;
    }

    private void doVersionCheck() {
        int currentVersion = BuildConfig.VERSION_CODE;
        int storedVersion = preferences.getInt("appVersion", 1);

        if (currentVersion > storedVersion) {
            preferences.edit().putInt("appVersion", currentVersion).apply();
        }
    }

    private void refreshBundledSupportFiles() {
        File targetRootFolder = getTargetRootFolder();

        // These files come from the APK. ROM archives are user-generated and
        // are retained across support updates; native version checks request
        // re-extraction only when their format is actually incompatible.
        deleteIfExists(new File(targetRootFolder, "soh.otr"));
        deleteIfExists(new File(targetRootFolder, "soh.o2r"));
        deleteIfExists(getSupportFilesMarkerFile(targetRootFolder));
    }

    private File getSupportFilesMarkerFile(File targetRootFolder) {
        return new File(targetRootFolder, SUPPORT_FILES_VERSION_MARKER);
    }

    private boolean isSupportFilesMarkerCurrent() {
        File markerFile = getSupportFilesMarkerFile(getTargetRootFolder());
        if (!markerFile.exists()) {
            return false;
        }

        try (InputStream in = new FileInputStream(markerFile)) {
            byte[] buffer = new byte[(int) markerFile.length()];
            int read = in.read(buffer);
            if (read <= 0) {
                return false;
            }
            String markerVersion = new String(buffer, 0, read).trim();
            return markerVersion.equals(SUPPORT_FILES_VERSION);
        } catch (IOException e) {
            Log.w("setupFiles", "Unable to read support files marker", e);
            return false;
        }
    }

    private void writeSupportFilesMarker(File targetRootFolder) throws IOException {
        File markerFile = getSupportFilesMarkerFile(targetRootFolder);
        try (OutputStream out = new FileOutputStream(markerFile)) {
            out.write(SUPPORT_FILES_VERSION.getBytes());
        }
    }

    private void deleteIfExists(File file) {
        if (file.exists()) {
            if (file.delete()) {
                Log.i("deleteAssets", "Deleted file: " + file.getAbsolutePath());
            } else {
                Log.w("deleteAssets", "Failed to delete file: " + file.getAbsolutePath());
            }
        } else {
            Log.i("deleteAssets", "File not found (skipped): " + file.getAbsolutePath());
        }
    }

    private void deleteRecursiveIfExists(File dir) throws IOException {
        if (dir.exists()) {
            deleteRecursive(dir);
            Log.i("deleteAssets", "Deleted directory: " + dir.getAbsolutePath());
        } else {
            Log.i("deleteAssets", "Directory not found (skipped): " + dir.getAbsolutePath());
        }
    }

    private void deleteRecursive(File fileOrDirectory) throws IOException {
        if (fileOrDirectory.isDirectory()) {
            File[] children = fileOrDirectory.listFiles();
            if (children == null) {
                throw new IOException("Unable to list bundled asset directory: " + fileOrDirectory);
            }
            for (File child : children) {
                deleteRecursive(child);
            }
        }
        deleteRequiredFile(fileOrDirectory);
    }

    private void deleteRequiredFile(File file) throws IOException {
        if (file.exists() && !file.delete()) {
            throw new IOException("Unable to refresh bundled support file: " + file);
        }
    }

    private File getTargetRootFolder() {
        String configuredPath = preferences.getString(PREF_DATA_ROOT_PATH, null);
        if (configuredPath == null || configuredPath.isEmpty()) {
            return getDefaultDataRootFolder();
        }

        return new File(configuredPath);
    }

    private File getDefaultDataRootFolder() {
        return new File(Environment.getExternalStorageDirectory(), DATA_FOLDER_NAME);
    }

    private void updateCurrentDataRootPath() {
        currentDataRootPath = getTargetRootFolder().getAbsolutePath();
        Log.i("setupFiles", "Current data root: " + currentDataRootPath);
    }

    private void beginSetupOrChooseDataRoot() {
        if (!preferences.contains(PREF_DATA_ROOT_PATH)) {
            preferences.edit().putString(PREF_DATA_ROOT_PATH, getDefaultDataRootFolder().getAbsolutePath()).apply();
        }
        beginSetupIfStorageReady();
    }

    private static class DataRootOption {
        final String label;
        final File folder;

        DataRootOption(String label, File folder) {
            this.label = label;
            this.folder = folder;
        }
    }

    private List<DataRootOption> getDataRootOptions() {
        Map<String, DataRootOption> options = new LinkedHashMap<>();
        File defaultFolder = getDefaultDataRootFolder();
        options.put(defaultFolder.getAbsolutePath(),
                new DataRootOption("Internal storage: " + defaultFolder.getAbsolutePath(), defaultFolder));

        File[] externalDirs = getExternalFilesDirs(null);
        if (externalDirs != null) {
            for (File externalDir : externalDirs) {
                if (externalDir == null || !Environment.isExternalStorageRemovable(externalDir)) {
                    continue;
                }

                File volumeRoot = getVolumeRootFromExternalFilesDir(externalDir);
                if (volumeRoot == null) {
                    continue;
                }

                File sdFolder = new File(volumeRoot, DATA_FOLDER_NAME);
                options.put(sdFolder.getAbsolutePath(),
                        new DataRootOption("SD card: " + sdFolder.getAbsolutePath(), sdFolder));
            }
        }

        return new ArrayList<>(options.values());
    }

    private File getVolumeRootFromExternalFilesDir(File externalDir) {
        String path = externalDir.getAbsolutePath();
        String suffix = "/Android/data/" + getPackageName() + "/files";
        int suffixIndex = path.indexOf(suffix);
        if (suffixIndex > 0) {
            return new File(path.substring(0, suffixIndex));
        }

        File parent = externalDir;
        for (int i = 0; i < 4 && parent != null; i++) {
            parent = parent.getParentFile();
        }
        return parent;
    }

    private void showDataRootChooser(boolean restartRequired) {
        List<DataRootOption> options = getDataRootOptions();

        if (options.size() < 2) {
            runOnUiThread(() -> new AlertDialog.Builder(this)
                    .setTitle("Change Data Folder")
                    .setMessage("No alternate writable data folder was found. Insert or mount an SD card and try again.")
                    .setPositiveButton("OK", null)
                    .setCancelable(true)
                    .show());
            return;
        }

        runOnUiThread(() -> {
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            int padding = (int) (20 * getResources().getDisplayMetrics().density);
            layout.setPadding(padding, padding, padding, padding);

            TextView message = new TextView(this);
            message.setText("Choose where Ship of Harkinian stores saves, mods, settings, and support files.");
            message.setTextColor(Color.BLACK);
            layout.addView(message);

            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle("Change Data Folder")
                    .setView(layout)
                    .setNegativeButton("Cancel", null)
                    .setCancelable(true)
                    .create();

            for (DataRootOption option : options) {
                Button optionButton = new Button(this);
                optionButton.setAllCaps(false);
                optionButton.setText(option.label);
                optionButton.setTextColor(Color.BLACK);
                optionButton.setOnClickListener((view) -> {
                    dialog.dismiss();
                    Executors.newSingleThreadExecutor()
                            .execute(() -> applyDataRootSelection(option.folder, restartRequired));
                });
                layout.addView(optionButton);
            }

            dialog.show();
        });
    }

    private void applyDataRootSelection(File targetRootFolder, boolean restartRequired) {
        File previousRoot = getTargetRootFolder();
        Log.i("setupFiles", "Changing data root from " + previousRoot.getAbsolutePath() +
                " to " + targetRootFolder.getAbsolutePath());
        preferences.edit().putString(PREF_DATA_ROOT_PATH, targetRootFolder.getAbsolutePath()).apply();
        updateCurrentDataRootPath();

        if (!ensureTargetRootFolderReady(targetRootFolder)) {
            preferences.edit().putString(PREF_DATA_ROOT_PATH, previousRoot.getAbsolutePath()).apply();
            updateCurrentDataRootPath();
            showSetupFailure("The selected data folder is not writable.");
            return;
        }

        boolean willMigrateData = shouldMigrateExistingRoot(previousRoot, targetRootFolder) ||
                shouldMigrateExistingRoot(getDefaultDataRootFolder(), targetRootFolder);
        if (willMigrateData) {
            showDataRootMigrationDialog();
        }
        migrateExistingRootIfNeeded(previousRoot, targetRootFolder);
        migrateExistingRootIfNeeded(getDefaultDataRootFolder(), targetRootFolder);
        if (willMigrateData) {
            dismissDataRootMigrationDialog();
        }

        if (restartRequired) {
            runOnUiThread(() -> new AlertDialog.Builder(this)
                    .setTitle("Restart Required")
                    .setMessage("Ship of Harkinian will use the new data folder after restarting. Existing data was copied when needed; the old folder was left in place.")
                    .setCancelable(false)
                    .setPositiveButton("Close App", (dialog, which) -> finish())
                    .show());
            return;
        }

        beginSetupIfStorageReady();
    }

    private void showDataRootMigrationDialog() {
        runOnUiThread(() -> {
            if (dataRootMigrationDialog != null && dataRootMigrationDialog.isShowing()) {
                return;
            }

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            int padding = (int) (20 * getResources().getDisplayMetrics().density);
            layout.setPadding(padding, padding, padding, padding);

            ProgressBar progressBar = new ProgressBar(this);
            progressBar.setIndeterminate(true);
            layout.addView(progressBar);

            TextView message = new TextView(this);
            message.setText("Copying saves, mods, settings, and support files. This may take a few minutes.");
            message.setTextColor(Color.BLACK);
            layout.addView(message);

            dataRootMigrationDialog = new AlertDialog.Builder(this)
                    .setTitle("Moving Data Folder")
                    .setView(layout)
                    .setCancelable(false)
                    .create();
            dataRootMigrationDialog.show();
        });
    }

    private void dismissDataRootMigrationDialog() {
        runOnUiThread(() -> {
            if (dataRootMigrationDialog != null && dataRootMigrationDialog.isShowing()) {
                dataRootMigrationDialog.dismiss();
            }
            dataRootMigrationDialog = null;
        });
    }

    private void showSetupProgressDialog(String title, String text) {
        runOnUiThread(() -> {
            if (setupProgressDialog != null && setupProgressDialog.isShowing()) {
                return;
            }

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            int padding = (int) (20 * getResources().getDisplayMetrics().density);
            layout.setPadding(padding, padding, padding, padding);

            ProgressBar progressBar = new ProgressBar(this);
            progressBar.setIndeterminate(true);
            layout.addView(progressBar);

            TextView message = new TextView(this);
            message.setText(text);
            message.setTextColor(Color.BLACK);
            layout.addView(message);

            setupProgressDialog = new AlertDialog.Builder(this)
                    .setTitle(title)
                    .setView(layout)
                    .setCancelable(false)
                    .create();
            setupProgressDialog.show();
        });
    }

    private void dismissSetupProgressDialog() {
        runOnUiThread(() -> {
            if (setupProgressDialog != null && setupProgressDialog.isShowing()) {
                setupProgressDialog.dismiss();
            }
            setupProgressDialog = null;
        });
    }

    private void migrateExistingRootIfNeeded(File sourceRoot, File targetRoot) {
        if (!shouldMigrateExistingRoot(sourceRoot, targetRoot)) {
            return;
        }

        try {
            Log.i("setupFiles", "Copying existing data from " + sourceRoot.getAbsolutePath() +
                    " to " + targetRoot.getAbsolutePath());
            AssetCopyUtil.copyDirectoryContentsNoOverwrite(sourceRoot, targetRoot);
            Log.i("setupFiles", "Copied existing data from: " + sourceRoot.getAbsolutePath());
        } catch (IOException e) {
            Log.e("setupFiles", "Failed to copy existing data from: " + sourceRoot.getAbsolutePath(), e);
            runOnUiThread(() -> Toast.makeText(this, "Could not copy existing data", Toast.LENGTH_LONG).show());
        }
    }

    private boolean shouldMigrateExistingRoot(File sourceRoot, File targetRoot) {
        return sourceRoot != null && targetRoot != null &&
                !sourceRoot.getAbsolutePath().equals(targetRoot.getAbsolutePath()) &&
                sourceRoot.isDirectory() && isDirectoryEmpty(targetRoot);
    }

    private boolean isDirectoryEmpty(File directory) {
        File[] files = directory.listFiles();
        return files == null || files.length == 0;
    }



    // Check if storage permission is granted
    private boolean hasStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // Android 11 and above
            return Environment.isExternalStorageManager();
        } else {
            // Android 10 and below
            return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                            == PackageManager.PERMISSION_GRANTED;
        }
    }

    private static final int STORAGE_PERMISSION_REQUEST_CODE = 2296;
    private static final int FILE_PICKER_REQUEST_CODE = 0;

    private void requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // Android 11+ → MANAGE_EXTERNAL_STORAGE
            if (!Environment.isExternalStorageManager()) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, STORAGE_PERMISSION_REQUEST_CODE);
            } else {
                beginSetupOrChooseDataRoot();
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            // Android 6–10 → request READ/WRITE at runtime
            ActivityCompat.requestPermissions(this,
                    new String[]{
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                    },
                    STORAGE_PERMISSION_REQUEST_CODE);
        } else {
            // Below Android 6 → permissions granted at install time
            beginSetupOrChooseDataRoot();
        }
    }

    private void beginSetupIfStorageReady() {
        updateCurrentDataRootPath();
        File targetRootFolder = getTargetRootFolder();
        Log.i("setupFiles", "Beginning setup for data root: " + targetRootFolder.getAbsolutePath());
        if (!ensureTargetRootFolderReady(targetRootFolder)) {
            showStorageAccessFailure();
            return;
        }

        doVersionCheck();
        checkAndSetupFiles();
    }

    private boolean ensureTargetRootFolderReady(File targetRootFolder) {
        if (!isExternalStorageWritable() || !hasStoragePermission()) {
            return false;
        }

        if (!targetRootFolder.exists() && !targetRootFolder.mkdirs()) {
            Log.e("setupFiles", "Failed to create root folder: " + targetRootFolder.getAbsolutePath());
            return false;
        }

        if (!targetRootFolder.isDirectory() || !targetRootFolder.canWrite()) {
            Log.e("setupFiles", "Root folder is not writable: " + targetRootFolder.getAbsolutePath());
            return false;
        }

        File probeFile = new File(targetRootFolder, ".write_test");
        try (OutputStream out = new FileOutputStream(probeFile)) {
            out.write(0);
        } catch (IOException e) {
            Log.e("setupFiles", "Write probe failed for: " + targetRootFolder.getAbsolutePath(), e);
            return false;
        }

        if (probeFile.exists() && !probeFile.delete()) {
            Log.w("setupFiles", "Failed to delete write probe: " + probeFile.getAbsolutePath());
        }

        return true;
    }

    public void checkAndSetupFiles() {
        File targetRootFolder = getTargetRootFolder();
        File assetsFolder = new File(targetRootFolder, "assets");
        File sohOtrFile = new File(targetRootFolder, "soh.o2r");

        boolean isMissingAssets = !assetsFolder.exists() || assetsFolder.listFiles() == null || assetsFolder.listFiles().length == 0;
        boolean isMissingSohOtr = !sohOtrFile.isFile() || sohOtrFile.length() == 0;

        if (!targetRootFolder.exists() || isMissingAssets || isMissingSohOtr || !isSupportFilesMarkerCurrent()
                || !ExtractorAssetState.isCurrent(targetRootFolder, getBundledExtractorVersion())) {
            showSetupProgressDialog("Preparing Data Folder",
                    "Copying required support files. Please keep Ship of Harkinian open; SD cards may take a few minutes.");
            Executors.newSingleThreadExecutor().execute(() -> setupFilesInBackground(targetRootFolder));
        } else {
            setupLatch.countDown();
        }
    }

    private String getBundledExtractorVersion() {
        try (InputStream input = getAssets().open("extractor.version")) {
            byte[] bytes = new byte[128];
            int count = input.read(bytes);
            String revision = count > 0 ? new String(bytes, 0, count, java.nio.charset.StandardCharsets.UTF_8).trim() : "";
            return revision.matches("[0-9a-f]{64}") ? revision : null;
        } catch (IOException e) {
            Log.e("setupFiles", "Missing bundled extractor revision", e);
            return null;
        }
    }

    private void setupFilesInBackground(File targetRootFolder) {
        boolean setupFailed = false;
        Log.i("setupFiles", "Copying support files to: " + targetRootFolder.getAbsolutePath());

        if (!ensureTargetRootFolderReady(targetRootFolder)) {
            dismissSetupProgressDialog();
            showStorageAccessFailure();
            return;
        }

        String extractorVersion = getBundledExtractorVersion();
        if (extractorVersion == null) {
            dismissSetupProgressDialog();
            showSetupFailure("The bundled extractor version is missing. Please install a complete APK build.");
            return;
        }
        // Read legacy state before refreshing its support marker. Code/shader-only
        // updates must not delete and recopy over 20,000 unchanged YAML files.
        boolean copyExtractor = ExtractorAssetState.needsCopy(targetRootFolder, extractorVersion);
        if (!isSupportFilesMarkerCurrent()) {
            refreshBundledSupportFiles();
        }

        migrateLegacyAppDataIfNeeded(targetRootFolder);

        // Always ensure mods folder exists
        File targetModsDir = new File(targetRootFolder, "mods");
        if (!targetModsDir.exists() && !targetModsDir.mkdirs()) {
            dismissSetupProgressDialog();
            showSetupFailure("Failed to create the mods folder.");
            return;
        }

        // Copy assets/ from internal
        File targetAssetsDir = new File(targetRootFolder, "assets");
        try {
            if (copyExtractor) {
                // Invalidate first: an interrupted copy must never look complete.
                deleteRequiredFile(getSupportFilesMarkerFile(targetRootFolder));
                deleteRequiredFile(new File(targetRootFolder, ExtractorAssetState.MARKER));
                deleteRecursiveIfExists(targetAssetsDir);
                if (!targetAssetsDir.mkdirs() && !targetAssetsDir.isDirectory()) {
                    throw new IOException("Failed to create assets folder: " + targetAssetsDir.getAbsolutePath());
                }
                AssetCopyUtil.copyAssetsToExternal(this, "assets", targetAssetsDir.getAbsolutePath());
                Log.i("setupFiles", "Extractor files copied for revision " + extractorVersion);
            } else {
                Log.i("setupFiles", "Reusing unchanged extractor files");
            }
            ExtractorAssetState.markComplete(targetRootFolder, extractorVersion);
        } catch (IOException e) {
            e.printStackTrace();
            setupFailed = true;
            runOnUiThread(() -> Toast.makeText(this, "Error copying assets", Toast.LENGTH_LONG).show());
        }

        // The matching support archive is required and bundled with this APK.
        File supportArchive = new File(targetRootFolder, "soh.o2r");
        if (!isSupportFilesMarkerCurrent() || !supportArchive.isFile() || supportArchive.length() == 0) {
            try (InputStream assetIn = getAssets().open("soh.o2r")) {
                File targetOtrFile = new File(targetRootFolder, "soh.o2r");
                targetOtrFile.delete();
                try (OutputStream out = new FileOutputStream(targetOtrFile)) {
                    byte[] buffer = new byte[COPY_BUFFER_SIZE];
                    int read;
                    while ((read = assetIn.read(buffer)) != -1) {
                        out.write(buffer, 0, read);
                    }
                }
                runOnUiThread(() -> Toast.makeText(this, "soh.o2r copied", Toast.LENGTH_SHORT).show());
            } catch (IOException e) {
                Log.e("setupFiles", "Failed to copy bundled soh.o2r", e);
                setupFailed = true;
            }
        }

        if (setupFailed) {
            dismissSetupProgressDialog();
            showSetupFailure("Required support files could not be copied. Please install a complete APK build.");
            return;
        }

        try {
            writeSupportFilesMarker(targetRootFolder);
        } catch (IOException e) {
            Log.e("setupFiles", "Failed to write support files marker", e);
            dismissSetupProgressDialog();
            showSetupFailure("Required support files could not be finalized.");
            return;
        }

        dismissSetupProgressDialog();
        setupLatch.countDown();
    }

    private void migrateLegacyAppDataIfNeeded(File targetRootFolder) {
        if (preferences.getBoolean(PREF_LEGACY_DATA_MIGRATION_COMPLETE, false)) {
            return;
        }

        File sourceOldRoot = getExternalFilesDir(null);
        File sourceSavesDir = sourceOldRoot == null ? null : new File(sourceOldRoot, "Save");
        if (sourceOldRoot == null || sourceSavesDir == null || !sourceSavesDir.isDirectory()) {
            preferences.edit().putBoolean(PREF_LEGACY_DATA_MIGRATION_COMPLETE, true).apply();
            return;
        }

        Log.i("setupFiles", "Migrating old data without overwriting current files: " + sourceOldRoot.getAbsolutePath());

        File[] sourceFiles = sourceOldRoot.listFiles();
        if (sourceFiles != null) {
            for (File file : sourceFiles) {
                String name = file.getName();
                if (name.equals("assets") || name.equals("soh.otr") || name.equals("oot-mq.otr") ||
                        name.equals("oot.otr") || name.equals("soh.o2r") || name.equals("oot-mq.o2r") ||
                        name.equals("oot.o2r")) {
                    continue;
                }

                File dest = new File(targetRootFolder, name);
                try {
                    if (file.isDirectory()) {
                        AssetCopyUtil.copyDirectoryNoOverwrite(file, dest);
                    } else {
                        AssetCopyUtil.copyFileNoOverwrite(file, dest);
                    }
                    Log.i("setupFiles", "Migrated missing legacy data: " + name);
                } catch (IOException e) {
                    Log.e("setupFiles", "Failed to migrate legacy data: " + name, e);
                }
            }
        }

        preferences.edit().putBoolean(PREF_LEGACY_DATA_MIGRATION_COMPLETE, true).apply();
        runOnUiThread(() -> Toast.makeText(this, "Existing save data checked", Toast.LENGTH_SHORT).show());
    }

    private void showSetupFailure(String message) {
        setupLatch.countDown();
        runOnUiThread(() -> new AlertDialog.Builder(this)
                .setTitle("Setup Failed")
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton("Close", (dialog, which) -> finish())
                .show());
    }




    private native void nativeHandleSelectedFile(String filePath);
    private native void nativeDialogResult(int result);

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_PICKER_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            // Handle file selection
            Uri selectedFileUri = data.getData();
            String fileName = "OOT.z64";

            File destinationDirectory = getTargetRootFolder();
            File destinationFile = new File(destinationDirectory, fileName);

            if (selectedFileUri != null && ensureTargetRootFolderReady(destinationDirectory)) {
                destinationFile.delete();
                try (InputStream in = getContentResolver().openInputStream(selectedFileUri);
                     OutputStream out = new FileOutputStream(destinationFile)) {
                    byte[] buffer = new byte[COPY_BUFFER_SIZE];
                    int bytesRead;
                    while ((bytesRead = in.read(buffer)) != -1) {
                        out.write(buffer, 0, bytesRead);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    nativeHandleSelectedFile(null);
                    showSetupFailure("The selected file could not be copied into the SOH folder.");
                    return;
                }
            } else {
                showStorageAccessFailure();
                return;
            }

            if (destinationFile.exists() && destinationFile.length() > 0) {
                nativeHandleSelectedFile(destinationFile.getPath());
            } else {
                runOnUiThread(() -> Toast.makeText(this, "Failed to copy ROM file", Toast.LENGTH_LONG).show());
                nativeHandleSelectedFile(null);
            }

        } else if (requestCode == FILE_PICKER_REQUEST_CODE) {
            nativeHandleSelectedFile(null);
        } else if (requestCode == STORAGE_PERMISSION_REQUEST_CODE) {
            // Handle MANAGE_EXTERNAL_STORAGE result
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (Environment.isExternalStorageManager()) {
                    beginSetupOrChooseDataRoot();
                } else {
                    showStorageAccessFailure();
                }
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == STORAGE_PERMISSION_REQUEST_CODE) {
            if (hasStoragePermission()) {
                beginSetupOrChooseDataRoot();
            } else {
                showStorageAccessFailure();
            }
        }
    }

    public void showAlertDialog(String title, String message, String btn1, String btn2) {
        runOnUiThread(() -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this)
                    .setTitle(title)
                    .setMessage(message)
                    .setCancelable(false)
                    .setPositiveButton(btn1, (dialog, which) -> nativeDialogResult(0));
            if (btn2 != null && !btn2.isEmpty()) {
                builder.setNegativeButton(btn2, (dialog, which) -> nativeDialogResult(1));
            }
            AlertDialog dialog = builder.create();
            // FLAG_NOT_FOCUSABLE prevents stealing SDL window focus so onWindowFocusChanged
            // is never called — SDL never fires FOCUS_LOST, ImGui keeps gamepad state intact,
            // SELECT/BACK menu toggle continues to work after dialog dismissal.
            dialog.getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
            dialog.show();
        });
    }

    public void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("*/*");
        runOnUiThread(() -> startActivityForResult(intent, 0));
    }

    public void changeDataFolderFromNative() {
        showDataRootChooser(true);
    }

    public String getAndroidVersionFromNative() {
        String release = Build.VERSION.RELEASE;
        if (release == null || release.isEmpty()) {
            return "Android API " + Build.VERSION.SDK_INT;
        }

        return "Android " + release + " (API " + Build.VERSION.SDK_INT + ")";
    }

    // Check if external storage is available and writable
    private boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED.equals(state);
    }

    private void showStorageAccessFailure() {
        runOnUiThread(() -> new AlertDialog.Builder(this)
                .setTitle("Storage Permission Required")
                .setMessage("The app needs file access to create and update the SOH folder. Please grant storage access and try again.")
                .setCancelable(false)
                .setPositiveButton("Open Settings", (dialog, which) -> requestStoragePermission())
                .setNegativeButton("Close", (dialog, which) -> finish())
                .show());
    }

    public native void attachController();
    public native void detachController();
    // Native method for setting button state
    public native void setButton(int button, boolean value);
    public native void setCameraState(int axis, float value);
    public native void setCameraTouchActive(boolean active);
    private native void setItemButtonPulse();
    private native void setItemButtonHeld(boolean held);

    // Native method for setting joystick axis value
    public native void setAxis(int axis, short value);

    // Signals C++ that the gamepad BACK/SELECT button was pressed, bypassing SDL.
    public native void nativeGamepadBackPressed();
    // Injects a directional menu nav key: dir 0=up 1=down 2=left 3=right.
    public native void nativeMenuNavKey(int dir, boolean pressed);
    // Touch "Jump" button -> Manual Jump (see ManualJump.cpp). Works without any key binding.
    public native void nativeTouchJump(boolean down);
    // Roll / sprint (see TouchActions.cpp)
    public native void nativeTouchRoll();
    public native boolean nativeIsSeparateRoll();
    public native void nativeTouchSprint(boolean down);
    public native int nativeGetStamina();
    // Tap an item icon to select it; A then uses it (see TouchActions.cpp). slot -1 = none.
    public native void nativeSetSelectedItem(int slot);
    public native boolean nativeIsItemSelectEnabled();

    public void SetFirstPersonAimingActive(boolean active) {
        mIsAiming = active;
    }

    @Override
    protected void onPause() {
        super.onPause();
        setItemButtonHeld(false);
        mIsAiming = false;
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
            int keyCode = event.getKeyCode();
            // SDL loses controller tracking after activity transitions; catch BACK at the activity level.
            boolean isGamepad = (event.getSource() & android.view.InputDevice.SOURCE_GAMEPAD) != 0
                             || (event.getSource() & android.view.InputDevice.SOURCE_JOYSTICK) != 0;
            if (keyCode == KeyEvent.KEYCODE_BUTTON_SELECT ||
                    (keyCode == KeyEvent.KEYCODE_BACK && isGamepad)) {
                nativeGamepadBackPressed();
            }
        }
        return super.dispatchKeyEvent(event);
    }

    private Button button1, button2, button3, button4;
    private Button buttonA, buttonB, buttonX, buttonY;
    private Button buttonDpadUp, buttonDpadDown, buttonDpadLeft, buttonDpadRight;
    private Button buttonLB, buttonRB, buttonZL, buttonZR, buttonStart, buttonBack;
    private Button buttonJump, buttonRoll, buttonRun;
    // Tap targets over the HUD's C-button item icons: 0 = C-left, 1 = C-down, 2 = C-right.
    private final Button[] itemSlots = new Button[3];
    private int selectedItemSlot = -1;
    private volatile boolean itemSelectActive = false;
    private final Handler staminaHandler = new Handler(Looper.getMainLooper());
    private Button buttonToggle;
    private FrameLayout leftJoystick;
    private ImageView leftJoystickKnob;
    private View overlayView;
    private ViewGroup buttonGroup;
    private int leftStickPointerId = MotionEvent.INVALID_POINTER_ID;
    private int rightStickPointerId = MotionEvent.INVALID_POINTER_ID;
    private float leftStickStartX;
    private float leftStickStartY;
    private float leftStickFixedX = Float.NaN;
    private float leftStickFixedY = Float.NaN;
    private float rightStickStartX;
    private float rightStickStartY;
    private boolean touchControlsMenuVisible = false;

    // ---- Movable touch-button layout ----
    private static final String PREF_STICK_X = "touchStickFixedX";
    private static final String PREF_STICK_Y = "touchStickFixedY";
    private boolean touchEditMode = false;
    private float leftStickDefaultX = Float.NaN;
    private float leftStickDefaultY = Float.NaN;

    private static class MoveGroup {
        final String name;
        final View[] moved;    // views whose translation is changed together
        final View[] targets;  // views that receive the drag touch listener
        MoveGroup(String name, View[] moved, View[] targets) {
            this.name = name;
            this.moved = moved;
            this.targets = targets;
        }
    }
    private final List<MoveGroup> moveGroups = new ArrayList<>();
    private final Map<View, Float> baseScale = new HashMap<>();
    private static final String PREF_STICK_SCALE = "touchScale_stick";
    private static final float SCALE_MIN = 0.5f;
    private static final float SCALE_MAX = 2.0f;

    private static String groupLabel(String name) {
        switch (name) {
            case "face": return "ปุ่ม A / B / X / Y";
            case "dpad": return "ปุ่มลูกศร (D-pad)";
            case "lb": return "ปุ่ม L";
            case "rb": return "ปุ่ม R";
            case "zl": return "ปุ่ม ZL";
            case "zr": return "ปุ่ม ZR";
            case "start": return "ปุ่ม Start";
            case "back": return "ปุ่ม Back";
            case "jump": return "ปุ่มกระโดด (Jump)";
            case "roll": return "ปุ่มกลิ้ง (Roll)";
            case "run": return "ปุ่มวิ่ง (Run)";
            case "itemL": return "จุดแตะไอเทม C ซ้าย";
            case "itemD": return "จุดแตะไอเทม C ล่าง";
            case "itemR": return "จุดแตะไอเทม C ขวา";
            default: return name;
        }
    }

    // Function to set up the controller overlay (inflate layout and initialize buttons)
    private void setupControllerOverlay() {
        // Inflate the touchcontrol_overlay layout
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        overlayView = inflater.inflate(R.layout.touchcontrol_overlay, null);

        // Set layout params for overlayView to control positioning and sizing
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        );
        overlayView.setLayoutParams(layoutParams);
        // Add overlay view to the main layout (you may need to add it to a container like FrameLayout)
        ViewGroup view = (ViewGroup) findViewById(android.R.id.content);
        view.addView(overlayView);
        view.setKeepScreenOn(true);

        buttonGroup = overlayView.findViewById(R.id.button_group);

        buttonA = overlayView.findViewById(R.id.buttonA);
        buttonB = overlayView.findViewById(R.id.buttonB);
        buttonX = overlayView.findViewById(R.id.buttonX);
        buttonY = overlayView.findViewById(R.id.buttonY);
        applyTouchFaceButtonLayout(preferences.getInt(
                PREF_TOUCH_FACE_BUTTON_LAYOUT, TOUCH_FACE_BUTTON_LAYOUT_ABXY));

        buttonDpadUp = overlayView.findViewById(R.id.buttonDpadUp);
        buttonDpadDown = overlayView.findViewById(R.id.buttonDpadDown);
        buttonDpadLeft = overlayView.findViewById(R.id.buttonDpadLeft);
        buttonDpadRight = overlayView.findViewById(R.id.buttonDpadRight);

        buttonLB = overlayView.findViewById(R.id.buttonLB);
        buttonRB = overlayView.findViewById(R.id.buttonRB);
        buttonZL = overlayView.findViewById(R.id.buttonZL);
        buttonZR = overlayView.findViewById(R.id.buttonZR);

        buttonStart = overlayView.findViewById(R.id.buttonStart);
        buttonBack = overlayView.findViewById(R.id.buttonBack);

        buttonJump = overlayView.findViewById(R.id.buttonJump);
        buttonRoll = overlayView.findViewById(R.id.buttonRoll);
        buttonRun = overlayView.findViewById(R.id.buttonRun);
        itemSlots[0] = overlayView.findViewById(R.id.buttonItemLeft);
        itemSlots[1] = overlayView.findViewById(R.id.buttonItemDown);
        itemSlots[2] = overlayView.findViewById(R.id.buttonItemRight);

        buttonToggle = overlayView.findViewById(R.id.buttonToggle);

        // Initialize joysticks and joystick knobs from the inflated layout
        leftJoystick = overlayView.findViewById(R.id.left_joystick);
        leftJoystickKnob = overlayView.findViewById(R.id.left_joystick_knob);

        FrameLayout leftScreenArea = overlayView.findViewById(R.id.left_screen_area);
        FrameLayout rightScreenArea = overlayView.findViewById(R.id.right_screen_area);

        attachGameTouchListeners();
        buildMoveGroups();
        applySavedButtonPositions();
        positionItemSlotsWhenLaidOut();
        applyAllScalesWhenLaidOut();

        setupFloatingJoystick(leftScreenArea);
        setupLookAround(rightScreenArea);

        setupToggleButton(buttonToggle,buttonGroup);
        startStaminaPolling();
        applyTouchLeftStickMode();
        applyTouchControlsVisibility();

        // Exclude Back/Start from gesture nav zones (they sit at screen edges in landscape).
        // Must be called on each button in its own local coordinates.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ViewTreeObserver.OnGlobalLayoutListener gestureListener = new ViewTreeObserver.OnGlobalLayoutListener() {
                @Override
                public void onGlobalLayout() {
                    overlayView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    Rect selfRect = new Rect(0, 0, buttonBack.getWidth(), buttonBack.getHeight());
                    buttonBack.setSystemGestureExclusionRects(Arrays.asList(selfRect));
                    selfRect = new Rect(0, 0, buttonStart.getWidth(), buttonStart.getHeight());
                    buttonStart.setSystemGestureExclusionRects(Arrays.asList(selfRect));
                }
            };
            overlayView.getViewTreeObserver().addOnGlobalLayoutListener(gestureListener);
        }

    }

    private void attachGameTouchListeners() {
        addJumpTouchListener(buttonJump);
        addRollTouchListener(buttonRoll);
        addSprintTouchListener(buttonRun);
        attachItemSlotListeners();
        setupCButtons(buttonDpadUp, ControllerButtons.BUTTON_DPAD_UP);
        setupCButtons(buttonDpadDown, ControllerButtons.BUTTON_DPAD_DOWN);
        setupCButtons(buttonDpadLeft, ControllerButtons.BUTTON_DPAD_LEFT);
        setupCButtons(buttonDpadRight, ControllerButtons.BUTTON_DPAD_RIGHT);

        addTouchListener(buttonLB, ControllerButtons.BUTTON_LB);
        addTouchListener(buttonRB, ControllerButtons.BUTTON_RB);
        addTouchListener(buttonZL, ControllerButtons.AXIS_LT);
        addTouchListener(buttonZR, ControllerButtons.AXIS_RT);

        addTouchListener(buttonStart, ControllerButtons.BUTTON_START);
        // BACK uses nativeGamepadBackPressed directly; setButton(BUTTON_BACK) feeds ImGuiKey_GamepadBack, unreliable when SDL Gamepads list is empty.
        buttonBack.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                nativeGamepadBackPressed();
            }
            return true;
        });
    }

    // ================= Movable touch buttons =================

    // ---------------- Button size ----------------

    private float getGroupScale(String name) {
        float v = preferences.getFloat("touchScale_" + name, 1.0f);
        return Math.max(SCALE_MIN, Math.min(SCALE_MAX, v));
    }

    private float getStickScale() {
        float v = preferences.getFloat(PREF_STICK_SCALE, 1.0f);
        return Math.max(SCALE_MIN, Math.min(SCALE_MAX, v));
    }

    private void applyStickScale() {
        if (leftJoystick == null) return;
        float sc = getStickScale();
        leftJoystick.setScaleX(sc);
        leftJoystick.setScaleY(sc);
    }

    private void applyGroupScale(MoveGroup g) {
        float sc = getGroupScale(g.name);
        // Scale around the centre of the whole group so the d-pad keeps its shape.
        float left = Float.MAX_VALUE, top = Float.MAX_VALUE;
        float right = -Float.MAX_VALUE, bottom = -Float.MAX_VALUE;
        for (View v : g.moved) {
            left = Math.min(left, v.getLeft());
            top = Math.min(top, v.getTop());
            right = Math.max(right, v.getRight());
            bottom = Math.max(bottom, v.getBottom());
        }
        float cx = (left + right) / 2f;
        float cy = (top + bottom) / 2f;
        for (View v : g.moved) {
            v.setPivotX(cx - v.getLeft());
            v.setPivotY(cy - v.getTop());
            v.setScaleX(sc);
            v.setScaleY(sc);
            baseScale.put(v, sc);
        }
    }

    private void applyAllScales() {
        for (MoveGroup g : moveGroups) {
            applyGroupScale(g);
        }
        applyStickScale();
    }

    private void applyAllScalesWhenLaidOut() {
        if (overlayView.getWidth() > 0 && buttonA.getWidth() > 0) {
            applyAllScales();
            return;
        }
        overlayView.getViewTreeObserver().addOnGlobalLayoutListener(
                new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        if (overlayView.getWidth() == 0 || buttonA.getWidth() == 0) return;
                        overlayView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                        applyAllScales();
                    }
                });
    }

    private void showScaleGroupPicker() {
        String[] names = new String[moveGroups.size() + 1];
        for (int i = 0; i < moveGroups.size(); i++) {
            names[i] = groupLabel(moveGroups.get(i).name);
        }
        names[moveGroups.size()] = "วงอนาล็อก";
        new AlertDialog.Builder(this)
                .setTitle("เลือกปุ่มที่จะปรับขนาด")
                .setItems(names, (d, i) -> showScaleSeekBar(i))
                .setNegativeButton("ปิด", null)
                .show();
    }

    private void showScaleSeekBar(int index) {
        final boolean isStick = index >= moveGroups.size();
        final MoveGroup group = isStick ? null : moveGroups.get(index);
        final String key = isStick ? PREF_STICK_SCALE : "touchScale_" + group.name;
        float current = isStick ? getStickScale() : getGroupScale(group.name);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = dpToPixels(20);
        layout.setPadding(pad, pad, pad, pad);

        final TextView label = new TextView(this);
        label.setText("ขนาด " + Math.round(current * 100) + "%");
        layout.addView(label);

        SeekBar bar = new SeekBar(this);
        final int minPct = Math.round(SCALE_MIN * 100);
        final int maxPct = Math.round(SCALE_MAX * 100);
        bar.setMax(maxPct - minPct);
        bar.setProgress(Math.round(current * 100) - minPct);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                int pct = progress + minPct;
                label.setText("ขนาด " + pct + "%");
                preferences.edit().putFloat(key, pct / 100f).apply();
                if (isStick) applyStickScale(); else applyGroupScale(group);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });
        layout.addView(bar);

        new AlertDialog.Builder(this)
                .setTitle(isStick ? "วงอนาล็อก" : groupLabel(group.name))
                .setView(layout)
                .setPositiveButton("เสร็จสิ้น", null)
                .setNeutralButton("ค่าเริ่มต้น", (d, w) -> {
                    preferences.edit().remove(key).apply();
                    if (isStick) applyStickScale(); else applyGroupScale(group);
                })
                .show();
    }

    // Called from the in-game (ImGui) menu through JNI.
    public void openTouchLayoutEditorFromNative() {
        runOnUiThread(() -> {
            if (overlayView != null && !touchEditMode) enterTouchEditMode();
        });
    }

    public void openTouchSizeEditorFromNative() {
        runOnUiThread(() -> {
            if (overlayView != null) showScaleGroupPicker();
        });
    }

    public void resetTouchLayoutFromNative() {
        runOnUiThread(() -> {
            if (overlayView != null) resetButtonPositions();
        });
    }


    private void buildMoveGroups() {
        moveGroups.clear();
        View cluster = overlayView.findViewById(R.id.action_button_cluster);
        View cross = overlayView.findViewById(R.id.imageView);
        moveGroups.add(new MoveGroup("face", new View[]{cluster},
                new View[]{cluster, buttonA, buttonB, buttonX, buttonY}));
        View[] dpad = new View[]{buttonDpadUp, buttonDpadDown, buttonDpadLeft, buttonDpadRight, cross};
        moveGroups.add(new MoveGroup("dpad", dpad, dpad));
        moveGroups.add(new MoveGroup("lb", new View[]{buttonLB}, new View[]{buttonLB}));
        moveGroups.add(new MoveGroup("rb", new View[]{buttonRB}, new View[]{buttonRB}));
        moveGroups.add(new MoveGroup("zl", new View[]{buttonZL}, new View[]{buttonZL}));
        moveGroups.add(new MoveGroup("zr", new View[]{buttonZR}, new View[]{buttonZR}));
        moveGroups.add(new MoveGroup("start", new View[]{buttonStart}, new View[]{buttonStart}));
        moveGroups.add(new MoveGroup("back", new View[]{buttonBack}, new View[]{buttonBack}));
        moveGroups.add(new MoveGroup("jump", new View[]{buttonJump}, new View[]{buttonJump}));
        moveGroups.add(new MoveGroup("roll", new View[]{buttonRoll}, new View[]{buttonRoll}));
        moveGroups.add(new MoveGroup("run", new View[]{buttonRun}, new View[]{buttonRun}));
        moveGroups.add(new MoveGroup("itemL", new View[]{itemSlots[0]}, new View[]{itemSlots[0]}));
        moveGroups.add(new MoveGroup("itemD", new View[]{itemSlots[1]}, new View[]{itemSlots[1]}));
        moveGroups.add(new MoveGroup("itemR", new View[]{itemSlots[2]}, new View[]{itemSlots[2]}));
    }

    private void applySavedButtonPositions() {
        for (MoveGroup g : moveGroups) {
            float tx = preferences.getFloat("touchPos_" + g.name + "_x", 0f);
            float ty = preferences.getFloat("touchPos_" + g.name + "_y", 0f);
            for (View v : g.moved) {
                v.setTranslationX(tx);
                v.setTranslationY(ty);
            }
        }
    }

    private void showTouchLayoutDialog() {
        String[] items = touchEditMode
                ? new String[]{"บันทึกและออกจากโหมดแก้ไข", "ปรับขนาดปุ่ม", "รีเซ็ตตำแหน่งและขนาดทั้งหมด"}
                : new String[]{"แก้ไขตำแหน่งปุ่ม (ลากปุ่มเพื่อย้าย)", "ปรับขนาดปุ่ม", "รีเซ็ตตำแหน่งและขนาดทั้งหมด"};
        new AlertDialog.Builder(this)
                .setTitle("ปุ่มควบคุมบนหน้าจอ")
                .setItems(items, (d, which) -> {
                    if (which == 0) {
                        if (touchEditMode) exitTouchEditMode(); else enterTouchEditMode();
                    } else if (which == 1) {
                        showScaleGroupPicker();
                    } else {
                        resetButtonPositions();
                    }
                })
                .setNegativeButton("ยกเลิก", null)
                .show();
    }

    private void enterTouchEditMode() {
        if (overlayView == null) return;
        touchEditMode = true;
        // If the buttons were hidden with the eye button, show them or there is nothing to drag.
        preferences.edit().putBoolean(PREF_TOUCH_CONTROLS_HIDDEN, false).apply();
        resetLeftStick();
        applyTouchControlsVisibility();

        for (MoveGroup g : moveGroups) {
            View.OnTouchListener drag = new View.OnTouchListener() {
                float downRawX, downRawY, startTx, startTy;
                @Override
                public boolean onTouch(View v, MotionEvent ev) {
                    switch (ev.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            downRawX = ev.getRawX();
                            downRawY = ev.getRawY();
                            startTx = g.moved[0].getTranslationX();
                            startTy = g.moved[0].getTranslationY();
                            return true;
                        case MotionEvent.ACTION_MOVE: {
                            float tx = startTx + (ev.getRawX() - downRawX);
                            float ty = startTy + (ev.getRawY() - downRawY);
                            for (View m : g.moved) {
                                m.setTranslationX(tx);
                                m.setTranslationY(ty);
                            }
                            return true;
                        }
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            preferences.edit()
                                    .putFloat("touchPos_" + g.name + "_x", g.moved[0].getTranslationX())
                                    .putFloat("touchPos_" + g.name + "_y", g.moved[0].getTranslationY())
                                    .apply();
                            return true;
                    }
                    return true;
                }
            };
            for (View t : g.targets) {
                t.setOnTouchListener(drag);
            }
        }

        // Analog stick: shown and draggable (this sets the position used in "fixed" stick mode).
        if (!Float.isNaN(leftStickFixedX)) {
            leftJoystick.setX(leftStickFixedX);
            leftJoystick.setY(leftStickFixedY);
        }
        centerLeftKnob();
        leftJoystick.setVisibility(View.VISIBLE);
        leftJoystick.setOnTouchListener(new View.OnTouchListener() {
            float downRawX, downRawY, startX, startY;
            @Override
            public boolean onTouch(View v, MotionEvent ev) {
                switch (ev.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = ev.getRawX();
                        downRawY = ev.getRawY();
                        startX = leftJoystick.getX();
                        startY = leftJoystick.getY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        leftJoystick.setX(startX + (ev.getRawX() - downRawX));
                        leftJoystick.setY(startY + (ev.getRawY() - downRawY));
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        leftStickFixedX = leftJoystick.getX();
                        leftStickFixedY = leftJoystick.getY();
                        preferences.edit()
                                .putFloat(PREF_STICK_X, leftStickFixedX)
                                .putFloat(PREF_STICK_Y, leftStickFixedY)
                                .apply();
                        return true;
                }
                return true;
            }
        });

        refreshItemSlotVisuals();
        syncItemSlotsWithSetting();
        Toast.makeText(this, "โหมดแก้ไข: ลากปุ่มเพื่อย้าย • แตะปุ่มรูปตาเพื่อบันทึกและออก",
                Toast.LENGTH_LONG).show();
    }

    private void exitTouchEditMode() {
        touchEditMode = false;
        leftJoystick.setOnTouchListener(null);
        refreshItemSlotVisuals();
        syncItemSlotsWithSetting();
        attachGameTouchListeners();
        applyTouchFaceButtonLayout(preferences.getInt(
                PREF_TOUCH_FACE_BUTTON_LAYOUT, TOUCH_FACE_BUTTON_LAYOUT_ABXY));
        // Non-button views (cluster, d-pad cross) must not keep a drag listener.
        for (MoveGroup g : moveGroups) {
            for (View t : g.targets) {
                if (!(t instanceof Button)) {
                    t.setOnTouchListener(null);
                }
            }
        }
        resetLeftStick();
        applyTouchLeftStickMode();
        applyTouchControlsVisibility();
    }

    private void resetButtonPositions() {
        SharedPreferences.Editor ed = preferences.edit();
        for (MoveGroup g : moveGroups) {
            ed.remove("touchPos_" + g.name + "_x").remove("touchPos_" + g.name + "_y");
        }
        for (MoveGroup g : moveGroups) {
            ed.remove("touchScale_" + g.name);
        }
        ed.remove(PREF_STICK_X).remove(PREF_STICK_Y).remove(PREF_STICK_SCALE).apply();
        applySavedButtonPositions();
        applyAllScales();
        if (!Float.isNaN(leftStickDefaultX)) {
            leftStickFixedX = leftStickDefaultX;
            leftStickFixedY = leftStickDefaultY;
            leftJoystick.setX(leftStickFixedX);
            leftJoystick.setY(leftStickFixedY);
        }
        applyTouchLeftStickMode();
    }

    public void setTouchControlsDisabledFromNative(boolean disabled) {
        preferences.edit().putBoolean(PREF_TOUCH_CONTROLS_DISABLED, disabled).apply();
        runOnUiThread(this::applyTouchControlsVisibility);
    }

    public void setTouchFaceButtonLayoutFromNative(int layout) {
        int normalizedLayout = layout >= TOUCH_FACE_BUTTON_LAYOUT_ABXY &&
                layout <= TOUCH_FACE_BUTTON_LAYOUT_GAMECUBE
                ? layout : TOUCH_FACE_BUTTON_LAYOUT_ABXY;
        preferences.edit().putInt(PREF_TOUCH_FACE_BUTTON_LAYOUT, normalizedLayout).apply();
        runOnUiThread(() -> applyTouchFaceButtonLayout(normalizedLayout));
    }

    public void setTouchLeftStickFloatingFromNative(boolean floating) {
        preferences.edit().putBoolean(PREF_TOUCH_LEFT_STICK_FLOATING, floating).apply();
        runOnUiThread(this::applyTouchLeftStickMode);
    }

    public void setTouchControlsMenuVisibleFromNative(boolean visible) {
        runOnUiThread(() -> {
            touchControlsMenuVisible = visible;
            applyTouchControlsVisibility();
        });
    }

    private void applyTouchLeftStickMode() {
        if (leftJoystick == null) {
            return;
        }
        applyStickScale();
        boolean floating = preferences.getBoolean(PREF_TOUCH_LEFT_STICK_FLOATING, true);
        if (!floating && !Float.isNaN(leftStickFixedX)) {
            leftJoystick.setX(leftStickFixedX);
            leftJoystick.setY(leftStickFixedY);
            leftJoystickKnob.setX(leftJoystick.getWidth() / 2.0f - leftJoystickKnob.getWidth() / 2.0f);
            leftJoystickKnob.setY(leftJoystick.getHeight() / 2.0f - leftJoystickKnob.getHeight() / 2.0f);
        }
        leftJoystick.setVisibility(floating && !touchEditMode ? View.INVISIBLE : View.VISIBLE);
    }

    private void applyTouchFaceButtonLayout(int layout) {
        if (buttonA == null || buttonB == null || buttonX == null || buttonY == null) {
            return;
        }

        FrameLayout actionButtonCluster = overlayView.findViewById(R.id.action_button_cluster);
        if (layout == TOUCH_FACE_BUTTON_LAYOUT_GAMECUBE) {
            setViewSize(actionButtonCluster, 200, 170);
            configureFaceButton(buttonA, 70, 70, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 20, 0, 0, 20);
            configureFaceButton(buttonB, 46, 46, Gravity.BOTTOM | Gravity.START, 30, 0, 0, 20);
            configureFaceButton(buttonX, 46, 46, Gravity.TOP | Gravity.END, 0, 37, 0, 0);
            configureFaceButton(buttonY, 46, 46, Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, 15, 0, 0);
        } else if (layout == TOUCH_FACE_BUTTON_LAYOUT_BAYX) {
            setViewSize(actionButtonCluster, 132, 132);
            configureFaceButton(buttonA, 44, 44, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0, 0, 0);
            configureFaceButton(buttonB, 44, 44, Gravity.CENTER_VERTICAL | Gravity.END, 0, 0, 0, 0);
            configureFaceButton(buttonX, 44, 44, Gravity.CENTER_VERTICAL | Gravity.START, 0, 0, 0, 0);
            configureFaceButton(buttonY, 44, 44, Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, 0, 0, 0);
        } else {
            setViewSize(actionButtonCluster, 132, 132);
            configureFaceButton(buttonB, 44, 44, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0, 0, 0);
            configureFaceButton(buttonA, 44, 44, Gravity.CENTER_VERTICAL | Gravity.END, 0, 0, 0, 0);
            configureFaceButton(buttonY, 44, 44, Gravity.CENTER_VERTICAL | Gravity.START, 0, 0, 0, 0);
            configureFaceButton(buttonX, 44, 44, Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, 0, 0, 0);
        }

        // Layout selection only moves the buttons. A button displaying a letter must
        // always emit that same logical SDL button, regardless of its screen position.
        addTouchListener(buttonA, ControllerButtons.BUTTON_A);
        addTouchListener(buttonB, ControllerButtons.BUTTON_B);
        addTouchListener(buttonX, ControllerButtons.BUTTON_X);
        addTouchListener(buttonY, ControllerButtons.BUTTON_Y);
    }

    private void configureFaceButton(Button button, int widthDp, int heightDp, int gravity,
                                     int marginStartDp, int marginTopDp,
                                     int marginEndDp, int marginBottomDp) {
        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) button.getLayoutParams();
        params.width = dpToPixels(widthDp);
        params.height = dpToPixels(heightDp);
        params.gravity = gravity;
        int marginStart = dpToPixels(marginStartDp);
        int marginEnd = dpToPixels(marginEndDp);
        params.setMargins(marginStart, dpToPixels(marginTopDp), marginEnd, dpToPixels(marginBottomDp));
        params.setMarginStart(marginStart);
        params.setMarginEnd(marginEnd);
        button.setLayoutParams(params);
    }

    private void setViewSize(View view, int widthDp, int heightDp) {
        ViewGroup.LayoutParams params = view.getLayoutParams();
        params.width = dpToPixels(widthDp);
        params.height = dpToPixels(heightDp);
        view.setLayoutParams(params);
    }

    private int dpToPixels(float dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }

    private void setTouchButtonPressed(Button button, boolean pressed) {
        button.setPressed(pressed);
        Float base = baseScale.get(button);
        float scale = (base == null ? 1.0f : base) * (pressed ? 0.92f : 1.0f);
        button.animate().scaleX(scale).scaleY(scale).setDuration(60).start();
    }

    private void applyTouchControlsVisibility() {
        if (overlayView == null) {
            return;
        }

        boolean touchControlsDisabled = preferences.getBoolean(PREF_TOUCH_CONTROLS_DISABLED, false);
        overlayView.setVisibility(touchControlsDisabled ? View.GONE : View.VISIBLE);

        if (buttonGroup != null) {
            boolean controlsHidden = preferences.getBoolean(PREF_TOUCH_CONTROLS_HIDDEN, false);
            buttonGroup.setVisibility(controlsHidden ? View.INVISIBLE : View.VISIBLE);
            if (touchEditMode && !controlsHidden && !touchControlsDisabled) {
                DisableTouchArea();
                overlayView.setOnTouchListener((view, e) -> true);
            } else if (controlsHidden || touchControlsDisabled || touchControlsMenuVisible) {
                DisableTouchArea();
                overlayView.setOnTouchListener(null);
            } else {
                EnableTouchArea();
                overlayView.setOnTouchListener((view, e) -> true);
            }
        }

        if (buttonToggle != null) {
            boolean toggleVisible = preferences.getBoolean("toggleButtonVisible", true);
            buttonToggle.setVisibility(!touchControlsDisabled && toggleVisible ? View.VISIBLE : View.GONE);
        }
    }

    private void setupToggleButton(Button button, ViewGroup uiGroup){
        button.setOnLongClickListener(v -> {
            showTouchLayoutDialog();
            return true;
        });
        button.setOnClickListener(v -> {
            if (touchEditMode) {
                // A single tap on the eye button saves and leaves the layout editor.
                exitTouchEditMode();
                Toast.makeText(this, "บันทึกตำแหน่งปุ่มแล้ว", Toast.LENGTH_SHORT).show();
                return;
            }
            boolean currentlyHidden = uiGroup.getVisibility() != View.VISIBLE;
            preferences.edit().putBoolean(PREF_TOUCH_CONTROLS_HIDDEN, !currentlyHidden).apply();
            applyTouchControlsVisibility();
        });
    }

    // Roll: a dedicated button when "Separate Roll Button" is on, otherwise it simply acts as A.
    private void addRollTouchListener(Button button) {
        if (touchEditMode || button == null) {
            return;
        }
        button.setOnTouchListener(new View.OnTouchListener() {
            private boolean actsAsA = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (nativeIsSeparateRoll()) {
                            actsAsA = false;
                            nativeTouchRoll();
                        } else {
                            actsAsA = true;
                            setButton(ControllerButtons.BUTTON_A, true);
                            nativeMenuNavKey(4, true);
                        }
                        setTouchButtonPressed(button, true);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (actsAsA) {
                            setButton(ControllerButtons.BUTTON_A, false);
                            nativeMenuNavKey(4, false);
                            actsAsA = false;
                        }
                        setTouchButtonPressed(button, false);
                        return true;
                }
                return false;
            }
        });
    }

    // Sprint: hold to run faster while stamina lasts (needs "Sprint Button" enabled in Settings).
    private void addSprintTouchListener(Button button) {
        if (touchEditMode || button == null) {
            return;
        }
        button.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    nativeTouchSprint(true);
                    setTouchButtonPressed(button, true);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    nativeTouchSprint(false);
                    setTouchButtonPressed(button, false);
                    return true;
            }
            return false;
        });
    }

    // Shows the stamina on the Run button: percent while fine, red "Tired" when out of breath.
    private void startStaminaPolling() {
        staminaHandler.removeCallbacksAndMessages(null);
        staminaHandler.post(new Runnable() {
            @Override
            public void run() {
                if (buttonRun != null && buttonRun.getVisibility() == View.VISIBLE) {
                    int v = nativeGetStamina();
                    if (v < 0) {
                        buttonRun.setText("Run");
                        if (buttonRun.getBackground() != null) buttonRun.getBackground().clearColorFilter();
                    } else {
                        boolean tired = v >= 1000;
                        int pct = v % 1000;
                        buttonRun.setText(tired ? "Tired" : "Run\n" + pct + "%");
                        if (buttonRun.getBackground() != null) {
                            if (tired) {
                                buttonRun.getBackground().setColorFilter(0xAAFF3030, PorterDuff.Mode.SRC_ATOP);
                            } else {
                                buttonRun.getBackground().clearColorFilter();
                            }
                        }
                    }
                }
                syncItemSlotsWithSetting();
                staminaHandler.postDelayed(this, 200);
            }
        });
    }

    // ---------------- Tap an item icon to select it ----------------

    // Default spot of the HUD's C icons (right-anchored, scaled by screen height like the game HUD).
    private void positionItemSlots() {
        if (overlayView == null || overlayView.getHeight() <= 0) return;
        float h = overlayView.getHeight();
        // {distance of icon centre from the right edge, from the top} as a fraction of the screen height
        float[][] spots = {{0.3333f, 0.1315f}, {0.2407f, 0.1972f}, {0.1528f, 0.1315f}};
        for (int i = 0; i < 3; i++) {
            Button b = itemSlots[i];
            if (b == null) continue;
            android.view.ViewGroup.LayoutParams raw = b.getLayoutParams();
            if (raw instanceof androidx.constraintlayout.widget.ConstraintLayout.LayoutParams) {
                androidx.constraintlayout.widget.ConstraintLayout.LayoutParams lp =
                        (androidx.constraintlayout.widget.ConstraintLayout.LayoutParams) raw;
                int size = dpToPixels(56);
                lp.rightMargin = Math.max(0, Math.round(spots[i][0] * h - size / 2f));
                lp.topMargin = Math.max(0, Math.round(spots[i][1] * h - size / 2f));
                b.setLayoutParams(lp);
            }
        }
    }

    private void positionItemSlotsWhenLaidOut() {
        if (overlayView.getHeight() > 0) {
            positionItemSlots();
            return;
        }
        overlayView.getViewTreeObserver().addOnGlobalLayoutListener(
                new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        if (overlayView.getHeight() == 0) return;
                        overlayView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                        positionItemSlots();
                    }
                });
    }

    private void attachItemSlotListeners() {
        if (touchEditMode) {
            return;
        }
        for (int i = 0; i < itemSlots.length; i++) {
            final int slot = i;
            Button b = itemSlots[i];
            if (b == null) continue;
            b.setOnTouchListener(null);
            b.setOnClickListener(v -> selectItemSlot(selectedItemSlot == slot ? -1 : slot));
        }
    }

    private void selectItemSlot(int slot) {
        selectedItemSlot = slot;
        itemSelectActive = slot >= 0;
        nativeSetSelectedItem(slot);
        refreshItemSlotVisuals();
    }

    // Transparent normally, a yellow ring on the selected icon, a dashed outline while editing the layout.
    private void refreshItemSlotVisuals() {
        for (int i = 0; i < itemSlots.length; i++) {
            Button b = itemSlots[i];
            if (b == null) continue;
            android.graphics.drawable.GradientDrawable ring = null;
            if (touchEditMode) {
                ring = new android.graphics.drawable.GradientDrawable();
                ring.setShape(android.graphics.drawable.GradientDrawable.OVAL);
                ring.setStroke(dpToPixels(2), 0xCCFFFFFF, dpToPixels(6), dpToPixels(4));
            } else if (i == selectedItemSlot) {
                ring = new android.graphics.drawable.GradientDrawable();
                ring.setShape(android.graphics.drawable.GradientDrawable.OVAL);
                ring.setStroke(dpToPixels(3), 0xFFFFD84A);
            }
            b.setBackground(ring);
        }
    }

    // Slots only exist while the "Tap item icons" option is on (or while editing the layout).
    private void syncItemSlotsWithSetting() {
        boolean enabled = nativeIsItemSelectEnabled();
        if (!enabled && selectedItemSlot >= 0) {
            selectItemSlot(-1);
        }
        for (Button b : itemSlots) {
            if (b != null) {
                b.setVisibility(enabled || touchEditMode ? View.VISIBLE : View.GONE);
            }
        }
    }

    private void addJumpTouchListener(Button button) {
        if (touchEditMode || button == null) {
            return;
        }
        button.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    nativeTouchJump(true);
                    setTouchButtonPressed(button, true);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    nativeTouchJump(false);
                    setTouchButtonPressed(button, false);
                    return true;
            }
            return false;
        });
    }

    // Function to set a touch listener for each button
    private void addTouchListener(Button button, int buttonNum) {
        if (touchEditMode) {
            return; // drag listeners are attached while editing; restored on exit
        }
        // dir>=4: face button nav keys (4=A/select, 5=B/back). -1 = no nav injection.
        int navDir = (buttonNum == ControllerButtons.BUTTON_A) ? 4
                   : (buttonNum == ControllerButtons.BUTTON_B) ? 5 : -1;
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        setButton(buttonNum, true);
                        if (navDir >= 0) nativeMenuNavKey(navDir, true);
                        setTouchButtonPressed(button, true);
                        return true;
                    case MotionEvent.ACTION_UP:
                        setButton(buttonNum, false);
                        if (navDir >= 0) nativeMenuNavKey(navDir, false);
                        setTouchButtonPressed(button, false);
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        setButton(buttonNum, false);
                        if (navDir >= 0) nativeMenuNavKey(navDir, false);
                        setTouchButtonPressed(button, false);
                        return true;
                }
                return false;
            }
        });
    }

    private void setupCButtons(Button button, int dpadButton) {
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        setButton(dpadButton, true);
                        nativeMenuNavKey(dpadButton - ControllerButtons.BUTTON_DPAD_UP, true);
                        setTouchButtonPressed(button, true);
                        return true;
                    case MotionEvent.ACTION_UP:
                        setButton(dpadButton, false);
                        nativeMenuNavKey(dpadButton - ControllerButtons.BUTTON_DPAD_UP, false);
                        setTouchButtonPressed(button, false);
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        setButton(dpadButton, false);
                        nativeMenuNavKey(dpadButton - ControllerButtons.BUTTON_DPAD_UP, false);
                        setTouchButtonPressed(button, false);
                        return true;
                }
                return false;
            }
        });
    }

    boolean TouchAreaEnabled = true;

    void DisableTouchArea(){
        TouchAreaEnabled = false;
        resetLeftStick();
        resetRightTouch();
    }
    void EnableTouchArea(){
        TouchAreaEnabled = true;
        applyTouchLeftStickMode();
    }

    void SetToggleButtonVisible(boolean visible) {
        runOnUiThread(() -> {
            preferences.edit().putBoolean("toggleButtonVisible", visible).apply();
            applyTouchControlsVisibility();
        });
    }

    private void centerLeftKnob() {
        leftJoystickKnob.setX(leftJoystick.getWidth() / 2.0f - leftJoystickKnob.getWidth() / 2.0f);
        leftJoystickKnob.setY(leftJoystick.getHeight() / 2.0f - leftJoystickKnob.getHeight() / 2.0f);
    }

    // Release the stick: axes to 0, knob back to the centre of the ring.
    private void releaseLeftStick() {
        leftStickPointerId = MotionEvent.INVALID_POINTER_ID;
        setAxis(ControllerButtons.AXIS_LX, (short) 0);
        setAxis(ControllerButtons.AXIS_LY, (short) 0);
        centerLeftKnob();
        if (preferences.getBoolean(PREF_TOUCH_LEFT_STICK_FLOATING, true)) {
            leftJoystick.setVisibility(View.INVISIBLE);
        }
    }

    private void setupFloatingJoystick(FrameLayout touchArea) {
        leftJoystick.post(() -> {
            leftStickDefaultX = leftJoystick.getX();
            leftStickDefaultY = leftJoystick.getY();
            leftStickFixedX = leftStickDefaultX;
            leftStickFixedY = leftStickDefaultY;
            if (preferences.contains(PREF_STICK_X) && preferences.contains(PREF_STICK_Y)) {
                leftStickFixedX = preferences.getFloat(PREF_STICK_X, leftStickFixedX);
                leftStickFixedY = preferences.getFloat(PREF_STICK_Y, leftStickFixedY);
            }
            applyTouchLeftStickMode();
        });
        touchArea.setOnTouchListener((view, event) -> {
            if (!TouchAreaEnabled || touchEditMode) {
                return false;
            }
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_POINTER_DOWN: {
                    int actionIndex = event.getActionIndex();
                    // A fresh ACTION_DOWN always restarts the stick (clears any stale pointer).
                    if (event.getActionMasked() == MotionEvent.ACTION_POINTER_DOWN
                            && leftStickPointerId != MotionEvent.INVALID_POINTER_ID) {
                        return true;
                    }
                    leftStickPointerId = event.getPointerId(actionIndex);
                    float downX = event.getX(actionIndex);
                    float downY = event.getY(actionIndex);
                    boolean floating = preferences.getBoolean(PREF_TOUCH_LEFT_STICK_FLOATING, true);
                    if (floating) {
                        leftStickStartX = downX;
                        leftStickStartY = downY;
                        leftJoystick.setX(leftStickStartX - leftJoystick.getWidth() / 2.0f);
                        leftJoystick.setY(leftStickStartY - leftJoystick.getHeight() / 2.0f);
                    } else {
                        leftStickStartX = leftJoystick.getX() + leftJoystick.getWidth() / 2.0f;
                        leftStickStartY = leftJoystick.getY() + leftJoystick.getHeight() / 2.0f;
                    }
                    centerLeftKnob();
                    leftJoystick.setVisibility(View.VISIBLE);
                    return true;
                }
                case MotionEvent.ACTION_MOVE: {
                    int idx = event.findPointerIndex(leftStickPointerId);
                    if (idx < 0) {
                        return true;
                    }
                    final float stickScale = getStickScale();
                    final float maxRadius = dpToPixels(51) * stickScale;
                    float deltaX = event.getX(idx) - leftStickStartX;
                    float deltaY = event.getY(idx) - leftStickStartY;
                    float distance = (float) Math.sqrt(deltaX * deltaX + deltaY * deltaY);
                    if (distance > maxRadius && distance > 0.0f) {
                        float scale = maxRadius / distance;
                        deltaX *= scale;
                        deltaY *= scale;
                    }
                    // The ring may be scaled; the knob lives inside it, so divide by the scale.
                    leftJoystickKnob.setX(leftJoystick.getWidth() / 2.0f + deltaX / stickScale -
                            leftJoystickKnob.getWidth() / 2.0f);
                    leftJoystickKnob.setY(leftJoystick.getHeight() / 2.0f + deltaY / stickScale -
                            leftJoystickKnob.getHeight() / 2.0f);
                    setAxis(ControllerButtons.AXIS_LX, (short) (deltaX / maxRadius * Short.MAX_VALUE));
                    setAxis(ControllerButtons.AXIS_LY, (short) (deltaY / maxRadius * Short.MAX_VALUE));
                    return true;
                }
                case MotionEvent.ACTION_POINTER_UP:
                    if (event.getPointerId(event.getActionIndex()) == leftStickPointerId) {
                        releaseLeftStick();
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    releaseLeftStick();
                    return true;
                default:
                    return true;
            }
        });
    }

    private void resetLeftStick() {
        leftStickPointerId = MotionEvent.INVALID_POINTER_ID;
        setAxis(ControllerButtons.AXIS_LX, (short) 0);
        setAxis(ControllerButtons.AXIS_LY, (short) 0);
        if (leftJoystick != null && leftJoystickKnob != null) {
            centerLeftKnob();
            if (!touchEditMode) {
                leftJoystick.setVisibility(View.INVISIBLE);
            }
        }
    }

    private void resetRightTouch() {
        rightStickPointerId = MotionEvent.INVALID_POINTER_ID;
        setAxis(ControllerButtons.AXIS_RX, (short) 0);
        setAxis(ControllerButtons.AXIS_RY, (short) 0);
        setCameraTouchActive(false);
        setCameraState(0, 0.0f);
        setCameraState(1, 0.0f);
        if (mIsAiming && !itemSelectActive) {
            setItemButtonHeld(false);
        }
    }

    private void setupLookAround(FrameLayout rightScreenArea) {
        rightScreenArea.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (!TouchAreaEnabled) {
                    return false;
                }

                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                    case MotionEvent.ACTION_POINTER_DOWN: {
                        if (rightStickPointerId == MotionEvent.INVALID_POINTER_ID) {
                            int pointerIndex = event.getActionIndex();
                            rightStickPointerId = event.getPointerId(pointerIndex);
                            rightStickStartX = event.getX(pointerIndex);
                            rightStickStartY = event.getY(pointerIndex);
                        }
                        if (mIsAiming) {
                            setCameraTouchActive(true);
                            if (!itemSelectActive) {
                                // Without a selected item, touching the screen holds the aim and lifting fires.
                                setItemButtonPulse();
                                setItemButtonHeld(true);
                            }
                        }
                        return true;
                    }

                    case MotionEvent.ACTION_MOVE: {
                        int pointerIndex = event.findPointerIndex(rightStickPointerId);
                        if (pointerIndex >= 0) {
                            float deltaX = event.getX(pointerIndex) - rightStickStartX;
                            float deltaY = event.getY(pointerIndex) - rightStickStartY;
                            float maxRadius = dpToPixels(51);
                            float distance = (float) Math.sqrt(deltaX * deltaX + deltaY * deltaY);
                            if (distance > maxRadius && distance > 0.0f) {
                                float scale = maxRadius / distance;
                                deltaX *= scale;
                                deltaY *= scale;
                            }

                            if (mIsAiming) {
                                // SOH's item-aiming path also handles the touch-to-fire gesture.
                                setAxis(ControllerButtons.AXIS_RX, (short) 0);
                                setAxis(ControllerButtons.AXIS_RY, (short) 0);
                                setCameraTouchActive(true);
                                setCameraState(0, deltaX / maxRadius * 170.0f);
                                setCameraState(1, deltaY / maxRadius * 170.0f);
                            } else {
                                // Match 2Ship: use the real virtual right-stick axes so
                                // controller deadzone, sensitivity, and inversion are shared.
                                setCameraTouchActive(false);
                                setCameraState(0, 0.0f);
                                setCameraState(1, 0.0f);
                                setAxis(ControllerButtons.AXIS_RX,
                                        (short) (deltaX / maxRadius * Short.MAX_VALUE));
                                setAxis(ControllerButtons.AXIS_RY,
                                        (short) (deltaY / maxRadius * Short.MAX_VALUE));
                            }
                        }
                        return true;
                    }

                    case MotionEvent.ACTION_POINTER_UP:
                    case MotionEvent.ACTION_UP:
                        if (event.getPointerId(event.getActionIndex()) == rightStickPointerId) {
                            resetRightTouch();
                        }
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        resetRightTouch();
                        return true;
                    default:
                        return true;
                }
            }
        });
    }





    // Function to set joystick movement with reset to center when not touched
    private void setupJoystick(FrameLayout joystickLayout, ImageView joystickKnob, boolean isLeft) {
        joystickLayout.post(() -> {
            // Calculate the joystick center once, before any events
            final float joystickCenterX = joystickLayout.getWidth() / 2f;
            final float joystickCenterY = joystickLayout.getHeight() / 2f;

            joystickLayout.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                        case MotionEvent.ACTION_MOVE:
                            // Calculate the joystick movement and move the knob
                            float deltaX = event.getX() - joystickCenterX;
                            float deltaY = event.getY() - joystickCenterY;

                            // Clamp the joystick movement to prevent it from going outside the area
                            float maxRadius = joystickLayout.getWidth() / 2f - joystickKnob.getWidth() / 2f;
                            float distance = (float) Math.sqrt(deltaX * deltaX + deltaY * deltaY);
                            if (distance > maxRadius) {
                                float scale = maxRadius / distance;
                                deltaX *= scale;
                                deltaY *= scale;
                            }

                            joystickKnob.setX(joystickCenterX + deltaX - joystickKnob.getWidth() / 2f);
                            joystickKnob.setY(joystickCenterY + deltaY - joystickKnob.getHeight() / 2f);

                            // Send joystick values to native C code
                            short x = (short) (deltaX / maxRadius * Short.MAX_VALUE);
                            short y = (short) (deltaY / maxRadius * Short.MAX_VALUE);

                            // Send X-axis and Y-axis values
                            setAxis(isLeft ? ControllerButtons.AXIS_LX : ControllerButtons.AXIS_RX, x); // X-axis
                            setAxis(isLeft ? ControllerButtons.AXIS_LY : ControllerButtons.AXIS_RY, y); // Y-axis
                            break;

                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            // Reset joystick knob to the center position (ensure it's placed correctly)
                            joystickKnob.setX(joystickCenterX - joystickKnob.getWidth() / 2f);
                            joystickKnob.setY(joystickCenterY - joystickKnob.getHeight() / 2f);

                            // Reset joystick values to 0 when released or canceled
                            setAxis(isLeft ? ControllerButtons.AXIS_LX : ControllerButtons.AXIS_RX, (short) 0); // X-axis
                            setAxis(isLeft ? ControllerButtons.AXIS_LY : ControllerButtons.AXIS_RY, (short) 0); // Y-axis
                            break;
                    }
                    return true;
                }
            });
        });


    }

    public void startRumble(int lowIntensity, int highIntensity) {
        int amplitude = Math.max(lowIntensity, highIntensity);
        for (int id : InputDevice.getDeviceIds()) {
            InputDevice device = InputDevice.getDevice(id);
            if (device == null) continue;
            int sources = device.getSources();
            if ((sources & InputDevice.SOURCE_GAMEPAD) != InputDevice.SOURCE_GAMEPAD &&
                (sources & InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK) continue;
            Vibrator dv = device.getVibrator();
            if (dv != null && dv.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    dv.vibrate(VibrationEffect.createOneShot(RUMBLE_MAX_DURATION_MS, amplitude > 0 ? amplitude : VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    dv.vibrate(RUMBLE_MAX_DURATION_MS);
                }
                return;
            }
        }
        Vibrator sv = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (sv != null && sv.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                sv.vibrate(VibrationEffect.createOneShot(RUMBLE_MAX_DURATION_MS, amplitude > 0 ? amplitude : VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                sv.vibrate(RUMBLE_MAX_DURATION_MS);
            }
        }
    }

    public void stopRumble() {
        for (int id : InputDevice.getDeviceIds()) {
            InputDevice device = InputDevice.getDevice(id);
            if (device == null) continue;
            int sources = device.getSources();
            if ((sources & InputDevice.SOURCE_GAMEPAD) != InputDevice.SOURCE_GAMEPAD &&
                (sources & InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK) continue;
            Vibrator dv = device.getVibrator();
            if (dv != null && dv.hasVibrator()) dv.cancel();
        }
        Vibrator sv = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (sv != null) sv.cancel();
    }

}
